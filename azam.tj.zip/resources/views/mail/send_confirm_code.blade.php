@component('mail::message')
Приветствуем вас в azam.tj! <br>
Ваш код подтверждения {{ $confirm }} <br>
@endcomponent
