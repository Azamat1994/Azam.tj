require('./bootstrap');
// require('./components/navbar');
// require('./components/dropdowns');
require('./components/select2');
require('./components/wizard');
require('./components/list');
require('./components/quill.js');
