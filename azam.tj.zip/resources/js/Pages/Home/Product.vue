<template>
    <app-layout class="wrapper" :cart="Object.keys(cart).length">
      <section id="content">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-lg-6">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb my-5">
                                <li class="breadcrumb-item"><a href="/">Главная</a></li>
                                <li class="breadcrumb-item" aria-current="page">Категории</li>
                                <li class="breadcrumb-item" v-if="product.category" aria-current="page">{{ product.category.name }}</li>
                                <li class="breadcrumb-item active" aria-current="page">{{ product.name }}</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col-12 col-lg-6">
                        <nav class="my-5 text-end">Артикул: {{ product.articul }}</nav>
                    </div>
                    <div class="az-single">
                        <div class="row">
                            <div class="col-12 col-lg-6">
                                <img :src="product.image[0]['fileName'] && '/storage/'+product.image[0]['fileName']" alt="" class="img-fluid" width="350" height="350">
                                <div class="az-single-gallery d-flex mt-3 flex-wrap">
                                    <img :src="item['fileName'] && '/storage/'+item['fileName']" class="me-3 mb-3" width="76" height="76" v-for="(item, index) in product.image" :key='index' @click="mainImage(item['fileName'] && '/storage/'+item['fileName'])">
                                </div>
                            </div>
                            <div class="col-12 col-lg-6 mt-5 mt-lg-0">
                                <h1 class="display-3 mb-4">{{ product.name }}</h1>
                                <!-- <span class="text-decoration-line-through fs-5">{{ product.price }} TJS</span> -->
                                <h2>{{ product.price }} TJS</h2>
                                <div class="az-single-params my-4">
                                    <div class="row">
                                        <div class="col-lg-6 col-12">
                                            <h5>Выбор цвета:</h5>
                                            <label for="color-red" class="me-2">
                                                <input class="form-check-input visually-hidden" type="radio" id="color-red" value="red" name="color">
                                                <span class="cursor-pointer border az-params-colors d-block">{{ product.color.name }}</span>
                                            </label>
                                        </div>
                                        <div class="col-lg-6 col-12">
                                            <h5>Выбор размера:</h5>
                                            <label for="size-12" class="me-2">
                                                <input class="form-check-input visually-hidden" type="radio" id="size-12" value="12" name="size">
                                                <span class="cursor-pointer fs-4">{{ product.size }}</span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="az-countable d-flex my-3 w-50">
                                    <button  @click="setQuantity('minus', cart[product.id])" type="button" class="btn p-0 shadow-none" id="az-countable-minus">
                                        <img src="/img/icons/minus.svg" width="35" height="35">
                                    </button>
                                    <input type="number" v-model="pcount" class="form-control border-0 mx-3 outline-fs-0 text-center fs-2 shadow-none" id="az-countable-count" min="1" :max="product.quantity" value="1" step="1">
                                    <button @click="setQuantity('plus', cart[product.id])" type="button" class="btn p-0 shadow-none" id="az-countable-plus">
                                        <img src="/img/icons/plus.svg" width="35" height="35">
                                    </button>
                                </div>
                                <div class="az-prdouct-payments d-flex">
                                    <button type="button" class="btn btn-danger text-white px-5 fs-5 rounded-0 me-3" @click="addToCartCustom(product.id)">Купить</button>
                                    <a :href="route('checkout')" class="btn btn-dark rounded-0">
                                        <img src="/img/icons/cart.svg" alt="" srcset="" width="35">
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="divider"></div>
                        <!-- <div class="az-details">
                            <div class="row">
                                <div class="col-12">
                                    <ul class="nav nav-pills mb-3 az-product-details" id="pills-tab" role="tablist">
                                        <li class="nav-item me-3" role="presentation">
                                            <a class="nav-link active fs-5 rounded-0 ps-0" id="pills-type-tab" data-bs-toggle="pill" href="#pills-type" role="tab" aria-controls="pills-type" aria-selected="true">Тип</a>
                                        </li>
                                        <li class="nav-item me-3" role="presentation">
                                            <a class="nav-link fs-5 rounded-0 ps-0" id="pills-outsole-tab" data-bs-toggle="pill" href="#pills-outsole" role="tab" aria-controls="pills-outsole" aria-selected="false">Подошва</a>
                                        </li>
                                        <li class="nav-item me-3" role="presentation">
                                            <a class="nav-link fs-5 rounded-0 ps-0" id="pills-girth-tab" data-bs-toggle="pill" href="#pills-girth" role="tab" aria-controls="pills-girth" aria-selected="false">Обхват</a>
                                        </li>
                                        <li class="nav-item me-3" role="presentation">
                                            <a class="nav-link fs-5 rounded-0 ps-0" id="pills-season-tab" data-bs-toggle="pill" href="#pills-season" role="tab" aria-controls="pills-contact" aria-selected="false">Сезон</a>
                                        </li>
                                    </ul>
                                    <hr>
                                    <div class="tab-content" id="pills-tabContent">
                                        <div class="tab-pane fade show active" id="pills-type" role="tabpanel" aria-labelledby="pills-type-tab">
                                            <h4 class="my-4">Типа</h4>
                                            <p class="lh-lg">
                                                MATOA Way Kambas - Sumatran Rhino comes with a material form of Makassar Ebony (Diospyros celebica). This wood is chosen to represent the Sumatran Rhino's skin which is designed with an overlap effect on its strap to represent Rhino's skin. Sumatran Rhino has unique skin fold, the skin is fairly thin about 10-16mm, and is soft and pliable.
                                            </p>
                                        </div>
                                        <div class="tab-pane fade lh-lg" id="pills-outsole" role="tabpanel" aria-labelledby="pills-outsole-tab">
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptas laborum optio quaerat iste magni culpa veniam ipsa, libero voluptatum consequuntur quidem sapiente, qui aliquam alias maxime! Tempore itaque libero explicabo.
                                        </div>
                                        <div class="tab-pane fade lh-lg" id="pills-girth" role="tabpanel" aria-labelledby="pills-girth-tab">
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptas laborum optio quaerat iste magni culpa veniam ipsa, libero voluptatum consequuntur quidem sapiente, qui aliquam alias maxime! Tempore itaque libero explicabo.
                                        </div>
                                        <div class="tab-pane fade lh-lg" id="pills-season" role="tabpanel" aria-labelledby="pills-season-tab">
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptas laborum optio quaerat iste magni culpa veniam ipsa, libero voluptatum consequuntur quidem sapiente, qui aliquam alias maxime! Tempore itaque libero explicabo.
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div> -->

                        <div class="divider"></div>

                        <div class="az-recomends-products">
                            <div class="product-news">
                                <div class="az-title d-flex mb-5">
                                    <hr class="col-1 bg-dark me-4">
                                    <h3>Рекоммендуемые товары</h3>
                                </div>

                                <div class="row row-cols-1 row-cols-md-4 g-4">
                                    <div class="col" v-for="(item, index) in recomended" :key="index">
                                        <div class="card bg-light recomends-products cursor-pointer border-0 p-4 pt-5">
                                            <img :src="'/storage/' + item.image[0]['fileName']" class="mx-auto img-fluid" width="211.48" height="225.78">
                                            <button class="btn btn-danger rounded-0 fw-bold position-absolute top-0 end-0 translate-middle text-white" type="button" v-if="item.sale">{{ item.sale }}% OFF</button>
                                            <div class="card-body">
                                                <h5 class="card-title"><a class="text-dark" :href="route('show-product', item.slug)">{{ item.name }}</a></h5>
                                                <nav class="card-text text-decoration-line-through">Rp 1.500.000</nav>
                                                <span class="fs-4 text-uppercase">{{ item.price }}</span>
                                            </div>
                                            <div class="az-add-product justify-content-around">
                                                <img src="/images/icons/product_cart.svg" @click="addToCart(item.id)">
                                                <button type="button" class="btn bg-brown text-white rounded-0 w-75" @click="addToCart(item.id)">Купить</button>
                                            </div>
                                            <a :href="route('show-product', product.slug)" class="stretched-link"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
         <div class="modal fade" id="cart" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl  modal-dialog-centered modal-fullscreen-sm-down">
          <div class="modal-content rounded-0 ">
            <div class="modal-body">
                <div class="orders">
                    <div class="row" v-for="(item, index) in cart" :key="index">
                        <div class="col">
                            <div class="d-flex">
                                <img :src="'/storage/' + item.image[0]['fileName']" alt="" width="145px" class="me-4">
                                <nav class="d-flex flex-column">
                                    <h5>{{ item.name }}</h5>
                                    <!-- <span class="text-decoration-line-through">300 TJS</span> -->
                                    <p class="fs-4 fw-bold">{{ item.price }} TJS</p>
                                    <span>Размер:</span>
                                    <span>{{ item.size }}</span>
                                </nav>
                            </div>
                        </div>
                        <div class="col">
                            <div class="d-flex align-content-between flex-column justify-content-between h-100 my-3 my-lg-0">
                                <div class="d-flex align-items-lg-center justify-content-between">
                                    <span>Количество</span>
                                    <span>Цена</span>
                                    <span class="text-muted cursor-pointer" @click="removeCart({clear: true})">Очистить корзину</span>
                                </div>
                                <div class="d-flex align-items-lg-center justify-content-between">
                                    <div class="az-countable d-flex">
                                        <button type="button" @click="setQuantity('minus', item)" class="btn p-0 shadow-none" id="az-countable-minus">
                                            <img src="/images/icons/minus.svg" width="35" height="35">
                                        </button>
                                        <input type="number" v-model="item.quantity" class="form-control border-0 mx-3 outline-fs-0 text-center fs-2 shadow-none w-50" id="az-countable-count" min="1" max="9999" value="1" step="1">
                                        <button type="button" @click="setQuantity('plus', item)" class="btn p-0 shadow-none" id="az-countable-plus">
                                            <img src="/images/icons/plus.svg" width="35" height="35">
                                        </button>
                                    </div>
                                    <h4 class="fw-bold">{{ item.price }} TJS</h4>
                                    <button type="button" @click="removeCart(item)" class="btn">
                                        <img src="/images/icons/trash.svg" alt="" srcset="">
                                    </button>
                                </div>
                            </div>
                        </div>
                        <hr class="mt-3">
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <!-- <p>Lorem Ipsum is simply dummy text of the printing <br>
                            and typesetting text ever since the 1500s, </p> -->
                    </div>
                    <div class="col-lg-6">
                        <!-- <nav class="text-decoration-line-through text-end">1100 TJs</nav> -->
                        <nav class="fs-5 text-end">Cумма: <strong class="fs-4">{{ getSumm }} TJS</strong></nav>
                    </div>
                </div>
            </div>
            <div class="modal-footer border-0">
              <a :href="route('checkout')" class="btn btn-danger text-white rounded-0 w-100 fs-4">Купить</a>
            </div>
          </div>
        </div>
      </div>
    </app-layout>
</template>

<script>
import Button from '../../Jetstream/Button.vue'
import AppLayout from './../../Layouts/AppLayout'
export default{
    components: {
        AppLayout
    },
    props: {
        product: Object,
        cartData: Object,
        recomended: Array
    },
    data() {
        return {
            seasons: [],
            colors: [],
            productCategories: [],
            products: {},
            cart: [],
            pcount: this.cartData[this.product.id] ? this.cartData[this.product.id].quantity : 1
        }
    },
    mounted() {
        this.cart = this.cartData
    },
    methods: {
        addToCart(id) {
            event.target.firstChild.classList.add('cart-animate')
            axios.post(route('addToCart', id))
            .then((response)=> {
                this.cart = response.data.cart
                this.$swal({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 2000,
                    timerProgressBar: true,
                    icon: 'success',
                    title: 'Товар добавлен в корзину'
                })
            })
        },
        addToCartCustom(id) {
            axios.post(route('addToCart', id))
            .then((response)=> {
                this.cart = response.data.cart
                this.$swal({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 2000,
                    timerProgressBar: true,
                    icon: 'success',
                    title: 'Товар добавлен в корзину'
                })
            })
        },
        setQuantity(type, item) {
            if (type === 'minus' && item.quantity > 1) {
                axios.post(route('setQuantity', type), item)
                .then(response=> {
                    this.cart = response.data.cart
                    this.pcount = this.cart[this.product.id].quantity
                })
            } else if (type === 'plus' && item) {
                axios.post(route('setQuantity', type), item)
                .then(response=> {
                    this.cart = response.data.cart
                    this.pcount = this.cart[this.product.id].quantity
                })
            }
        },
        removeCart(item) {
            axios.post(route('removeCart'), item)
            .then(response=> {
                this.cart = response.data.cart
            })
        },
        mainImage(url) {
            alert(url)
        }
    },
    computed: {
        getSumm() {
            let pc = 0;
            for (const [key, value] of Object.entries(this.cart)) {
                pc += (value.price * value.quantity)
            }
            return pc
        }
    }
}
</script>
