<template>
    <app-layout class="wrapper" :cart="Object.keys(cart).length">
        <section id="content">
            <div class="container">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb my-5">
                      <li class="breadcrumb-item"><a :href="route('home')">Главная</a></li>
                      <li class="breadcrumb-item active" aria-current="page">Ремонт</li>
                    </ol>
                </nav>

                <div class="az-repairs">
                    <div class="row row-cols-1 row-cols-lg-2 g-4">
                        <div class="col">
                          <div class="card py-3 border-0 bg-light">
                            <div class="card-body">
                                <h3 class="card-title">Ремонт от бренда <strong class="text-danger">“Азам”</strong></h3>
                                <p class="card-text">Вся обувь от нашего бренда ремонтируеться  на 50% дешевле.</p>
                            </div>
                            <label for="image" class="cursor-pointer">
                                <img :src="bidAzamImage ? bidAzamImage : '/images/icons/add_photos.svg'" class="card-img-top my-4" alt="..." width="100%" height="224px" style="object-fit: cover;">
                            </label>
                            <div class="card-body">
                                <form action="">
                                    <input type="file" class="d-none" name="image" id="image" @change="handleUpload($event, 0)">
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control feedback-input bg-light" id="name" v-model="bidAzam.name" name="name" placeholder="Введите имя">
                                        <label for="name">Имя</label>
                                    </div>
                                    <div class="form-floating mb-5">
                                        <input type="text" class="form-control feedback-input bg-light" id="phone" v-model="bidAzam.phone" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" name="phone" placeholder="Введите номер телефона">
                                        <label for="phone">Контакты</label>
                                    </div>
                                    <button type="button" :disabled="!showButton.t0" class="btn btn-outline-dark rounded-0 w-100 py-3 fs-4" @click="sendBid(0)">Отправить заявку</button>
                                </form>
                            </div>
                          </div>
                        </div>
                        <div class="col">
                            <div class="card py-3 border-0 bg-light">
                                <div class="card-body">
                                    <h3 class="card-title">Ремонт обуви другого <strong>Бренда</strong></h3>
                                    <p class="card-text">Оставьте заявку и мы оценим состояние вашей обуви для подготовки цены на ремонт</p>
                                </div>
                                <label for="other-image" class="cursor-pointer">
                                    <img :src="bidOtherImage ? bidOtherImage : '/images/icons/add_photos.svg'" class="card-img-top my-4" alt="..." width="100%" height="224px" style="object-fit: cover;">
                                </label>
                                <div class="card-body">
                                    <form action="" class="">
                                        <input type="file" class="d-none" name="image" id="other-image" @change="handleUpload($event, 1)">
                                        <div class="form-floating mb-3">
                                            <input type="text" class="form-control feedback-input bg-light" id="name" v-model="bidOther.name" placeholder="Введите имя">
                                            <label for="name">Имя</label>
                                        </div>
                                        <div class="form-floating mb-5">
                                            <input type="text" class="form-control feedback-input bg-light" id="phone" v-model="bidOther.phone" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" placeholder="Введите номер телефона">
                                            <label for="phone">Контакты</label>
                                        </div>
                                        <button type="button" :disabled="!showButton.t1" class="btn btn-outline-dark rounded-0 w-100 py-3 fs-4" @click="sendBid(1)">Отправить заявку</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="modal fade" id="cart" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl  modal-dialog-centered modal-fullscreen-sm-down">
          <div class="modal-content rounded-0 ">
            <div class="modal-body">
                <div class="orders">
                    <div class="row" v-for="(item, index) in cart" :key="index">
                        <div class="col">
                            <div class="d-flex">
                                <img :src="'/storage/' + item.image[0]['fileName']" alt="" width="145px" class="me-4">
                                <nav class="d-flex flex-column">
                                    <h5>{{ item.name }}</h5>
                                    <!-- <span class="text-decoration-line-through">300 TJS</span> -->
                                    <p class="fs-4 fw-bold">{{ item.price }} TJS</p>
                                    <span>Размер:</span>
                                    <span>{{ item.size }}</span>
                                </nav>
                            </div>
                        </div>
                        <div class="col">
                            <div class="d-flex align-content-between flex-column justify-content-between h-100 my-3 my-lg-0">
                                <div class="d-flex align-items-lg-center justify-content-between">
                                    <span>Количество</span>
                                    <span>Цена</span>
                                    <span class="text-muted cursor-pointer" @click="removeCart({clear: true})">Очистить корзину</span>
                                </div>
                                <div class="d-flex align-items-lg-center justify-content-between">
                                    <div class="az-countable d-flex">
                                        <button type="button" @click="setQuantity('minus', item)" class="btn p-0 shadow-none" id="az-countable-minus">
                                            <img src="/images/icons/minus.svg" width="35" height="35">
                                        </button>
                                        <input type="number" disabled v-model="item.quantity" class="form-control border-0 mx-3 outline-fs-0 text-center fs-2 shadow-none w-50" id="az-countable-count" min="1" max="9999" value="1" step="1">
                                        <button type="button" @click="setQuantity('plus', item)" class="btn p-0 shadow-none" id="az-countable-plus">
                                            <img src="/images/icons/plus.svg" width="35" height="35">
                                        </button>
                                    </div>
                                    <h4 class="fw-bold">{{ item.price }} TJS</h4>
                                    <button type="button" @click="removeCart(item)" class="btn">
                                        <img src="/images/icons/trash.svg" alt="" srcset="">
                                    </button>
                                </div>
                            </div>
                        </div>
                        <hr class="mt-3">
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <!-- <p>Lorem Ipsum is simply dummy text of the printing <br>
                            and typesetting text ever since the 1500s, </p> -->
                    </div>
                    <div class="col-lg-6">
                        <!-- <nav class="text-decoration-line-through text-end">1100 TJs</nav> -->
                        <nav class="fs-5 text-end">Cумма: <strong class="fs-4">{{ getSumm }} TJs</strong></nav>
                    </div>
                </div>
            </div>
            <div class="modal-footer border-0">
              <a :href="route('checkout')" class="btn btn-danger text-white  rounded-0 w-100 fs-4">Купить</a>
            </div>
          </div>
        </div>
        </div>
    </app-layout>
</template>

<script>
import AppLayout from './../../Layouts/AppLayout'
export default{
    components: {
        AppLayout
    },
    props: {
        lastProducts: Array,
        patrtners: Array,
        sliders: Array,
        cartData: Object
    },
    data() {
        return {
            showButton: {
                t0: true,
                t1: true
            },
            bidAzam: {
                name: '',
                phone: '',
                image: ''
            },
            bidOther: {
                name: '',
                phone: '',
                image: ''
            },
            bidOtherImage: '',
            bidAzamImage: '',
            cart: []
        }
    },
    mounted() {
        this.cart = this.cartData
    },
    methods: {
                addToCart(id) {
            event.target.firstChild.classList.add('cart-animate')
            axios.post(route('addToCart', id))
            .then((response)=> {
                this.cart = response.data.cart
                this.$swal({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 2000,
                    timerProgressBar: true,
                    icon: 'success',
                    title: 'Товар добавлен в корзину'
                })
            })
        },
        setQuantity(type, item) {
            if (type === 'minus' && item.quantity > 1) {
                axios.post(route('setQuantity', type), item)
                .then(response=> {
                    this.cart = response.data.cart
                })
            } else if (type === 'plus' && item) {
                axios.post(route('setQuantity', type), item)
                .then(response=> {
                    this.cart = response.data.cart
                })
            }
        },
        removeCart(item) {
            axios.post(route('removeCart'), item)
            .then(response=> {
                this.cart = response.data.cart
            })
        },
        handleUpload($event, type){
            if (type && $event.target.files.length>0){
                this.bidOther.image = $event.target.files[0]
                this.bidOtherImage = URL.createObjectURL(this.bidOther.image);
            } else if (!type && $event.target.files.length>0) {
                this.bidAzam.image = $event.target.files[0]
                this.bidAzamImage = URL.createObjectURL(this.bidAzam.image);
            }
        },
        sendBid(type){
            if (!(this.bidAzam.name && this.bidAzam.phone && this.bidAzam.image && type === 0) && !(this.bidOther.name && this.bidOther.phone && this.bidOther.image && type === 1)) {
                this.$swal({
                    position: 'top-end',
                    icon: 'error',
                    title: 'Введите корректные данные',
                    showConfirmButton: true,
                    timer: 2000
                })
                return 0
            }

            let fd = new FormData();

            fd.append('name', type === 1 ? this.bidOther.name : this.bidAzam.name);
            fd.append('phone', type === 1 ? this.bidOther.phone : this.bidAzam.phone);
            fd.append('image', type === 1 ? this.bidOther.image : this.bidAzam.image);
            fd.append('type', type);

            this.showButton['t'+type] = false

            axios.post(route('repairs-save'), fd, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            })
            .then(response=> {
                    this.$swal({
                        position: 'top-end',
                        icon: 'success',
                        title: response.data.message,
                        showConfirmButton: true,
                        timer: 2000
                    })
            })
            .catch(error=> {
                this.$swal({
                    position: 'top-end',
                    icon: 'error',
                    title: 'Введите корректные данные',
                    showConfirmButton: true,
                    timer: 2000
                })
            })
        }
    },
    computed: {
        getSumm() {
            let pc = 0;
            for (const [key, value] of Object.entries(this.cart)) {
                pc += (value.price * value.quantity)
            }
            return pc
        }
    }
}
</script>
