<template>
    <section id="footer" class="bg-dark">
        <footer class="pt-4 mt-md-5 pt-md-5 container text-light">
            <div class="row">
              <div class="col-12 col-md">
                <h5 class="mb-5">О Бренде</h5>
                <p class="lh-lg">
                    Наша продукция изготавливается в Таджикистане из высококачественной натуральной кожи и является абсолютно безопасной с экологической точки зрения.
                </p>
                <nav class="mt-5">
                    <h5>Рабочие часы</h5>
                    <p>Понедельник - Суббота
                        08.00 - 18.00</p>
                </nav>
              </div>
              <div class="col-6 col-md">
                <h5 class="mb-5">Помощь</h5>
                <ul class="list-unstyled lh-lg text-small">
                  <li><a class="link-light text-decoration-none" href="#">Статус заказа</a></li>
                  <li><a class="link-light text-decoration-none" href="#">Как оформить заказ?</a></li>
                  <li><a class="link-light text-decoration-none" href="#">Доставка и оплата</a></li>
                  <li><a class="link-light text-decoration-none" href="#">Гарантия и возврат</a></li>
                  <li><a class="link-light text-decoration-none" href="#">Таблица размеров</a></li>
                  <li><a class="link-light text-decoration-none" href="#">Книга жалоб</a></li>
                </ul>
              </div>
              <div class="col-6 col-md">
                <h5 class="mb-5">Информация</h5>
                <ul class="list-unstyled lh-lg text-small">
                  <li><a class="link-light text-decoration-none" href="#">О бренде</a></li>
                  <li><a class="link-light text-decoration-none" href="#">Новости</a></li>
                  <li><a class="link-light text-decoration-none" href="#">Акции</a></li>
                  <li><a class="link-light text-decoration-none" href="#">Контакты</a></li>
                </ul>
              </div>
              <div class="col-6 col-md">
                <h5 class="mb-5">Мой аккаунт</h5>
                <ul class="list-unstyled lh-lg text-small">
                  <li><a class="link-light text-decoration-none" href="#">Профиль</a></li>
                  <li><a class="link-light text-decoration-none" href="#">Корзина</a></li>
                  <li><a class="link-light text-decoration-none" href="#">Избранных</a></li>
                </ul>
              </div>
            </div>
            <div class="divider"></div>
          </footer>
    </section>
</template>

<script>
export default {

}
</script>
