<template>
        <nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light" id="sidebar">
            <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidebarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <a class="navbar-brand" href="/">
                    <img src="/images/logotype.png" class="navbar-brand-img mx-auto" alt="Logo">
                </a>

                <div class="navbar-user d-md-none">
                    <div class="dropdown">
                        <a href="#!" id="sidebarIcon" class="dropdown-toggle" role="button" data-toggle="dropdown">
                            <div class="avatar avatar-sm avatar-online">
                                <img src="/img/avatars/profiles/avatar-1.jpg" class="avatar-img rounded-circle" alt="Logo">
                            </div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="sidebarIcon">
                            <a href="#!" class="dropdown-item">!Профиль</a>
                            <a href="/account-general" class="dropdown-item">Настройки</a>
                            <hr class="dropdown-divider">
                            <a href="/logout" class="dropdown-item">Выйти</a>
                        </div>
                    </div>
                </div>

                <div class="collapse navbar-collapse" id="sidebarCollapse">
                    <form class="mt-4 mb-3 d-md-none">
                        <div class="input-group input-group-rounded input-group-merge">
                            <input type="search" class="form-control form-control-rounded form-control-prepended" placeholder="Поиск по админке...">
                            <div class="input-group-prepend">
                                <div class="input-group-text"><span class="fe fe-search"></span></div>
                            </div>
                        </div>
                    </form>
                    <hr class="navbar-divider my-3">
                    <h6 class="navbar-heading">Страницы</h6>
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="/dashboard/orders">
                                <i class="fe fe-list"></i> Заказы
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/dashboard/products">
                                <i class="fe fe-shopping-bag"></i> Продукты
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/dashboard/crudes">
                                <i class="fe fe-box"></i> Сырье
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/dashboard/warehouses">
                                <i class="fe fe-home"></i> Склады
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/dashboard/categories">
                                <i class="fe fe-grid"></i> Категории
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/dashboard/units">
                                <i class="fe fe-underline"></i> Единицы
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/dashboard/statuses">
                                <i class="fe fe-star"></i> Статусы
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/dashboard/users">
                                <i class="fe fe-user"></i> Пользователи
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/dashboard/roles">
                                <i class="fe fe-airplay"></i> Роли
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/dashboard/partners">
                                <i class="fe fe-users"></i> Партнёры
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/dashboard/sliders">
                                <i class="fe fe-layers"></i> Слайдеры
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/dashboard/get-bids">
                                <i class="fe fe-layers"></i> Заявки
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/dashboard/posts">
                                <i class="fe fe-layers"></i> Записи
                            </a>
                        </li>
                    </ul>
                </div>
                <div id="sidebarUser" class="navbar-user d-none d-md-flex"><div class="dropup"><a href="#" id="sidebarIconCopy" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" class="dropdown-toggle"><div class="avatar avatar-sm avatar-online"><img src="/images/avatar.png" alt="..." class="avatar-img rounded-circle"></div></a> <div aria-labelledby="sidebarIconCopy" class="dropdown-menu"><a href="#" onclick="alert('Страница находится на стадии разработки');" class="dropdown-item">Профиль</a> <hr class="dropdown-divider"> <a href="/logout" class="dropdown-item">Выйти</a></div></div></div>
            </div>
        </nav>
</template>
<script>

export default {
    components: {},
    data() {
        return {}
    },
    methods: {}
}
</script>
